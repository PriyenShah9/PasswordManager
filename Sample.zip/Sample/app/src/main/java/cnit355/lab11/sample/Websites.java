package cnit355.lab11.sample;

public class Websites {

    String Name;

    public Websites(String name) {
        Name = name;
    }
}
